
 //Personal API Key for OpenWeatherMap API
const apiKey = '5fc09aef58af57108e2a39f446b7e398';

// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click', performAction);

// Function called by event listener
function performAction() {
  const zipCode = document.getElementById('zip').value;
  const userResponse = document.getElementById('feelings').value;

  getWeatherData(zipCode)
    .then(function (data) {
      postData('/add', {
        temperature: data.main.temp,
        date: getCurrentDate(),
        userResponse: userResponse
      });
    })
    .then(function () {
      updateUI();
    });
}

// Function to get weather data from OpenWeatherMap API
const getWeatherData = async (zipCode) => {
  const url =` https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}&appid=${apiKey}`;
  const response = await fetch(url);
  const data = await response.json();
  return data;
};

// Function to post data to server
const postData = async (url = '', data = {}) => {
  const response = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(data)
  });
  try {
    const newData = await response.json();
    return newData;
  } catch (error) {
    console.log('error', error);
  }
};

// Function to update UI
const updateUI = async () => {
  const response = await fetch('/all');
  try {
    const data = await response.json();
    document.getElementById('date').innerHTML = data.date;
    document.getElementById('temp').innerHTML = `${Math.round(data.temperature)} degrees`;
    document.getElementById('content').innerHTML = data.userResponse;
  } catch (error) {
    console.log('error', error);
  }
};

// Function to get the current date
const getCurrentDate = () => {
  const d = new Date();
  const month = d.getMonth() + 1;
  const day = d.getDate();
  const year = d.getFullYear();
  return `${month}/${day}/${year}`;
};